#import "ExeContext.h"




void barcode_scanbarcode_binding(ExeContext *, int, int, unsigned char);
